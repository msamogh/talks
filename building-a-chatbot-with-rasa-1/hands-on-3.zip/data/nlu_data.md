## intent:query_open_positions
- I'm looking for job openings at your company
- Do you have available positions for a [technical](role) role?
- I'm working in the [tech](role) industry currently looking for open positions at your company.
- What are the available jobs at your firm? My current pincode is [782331](pincode)
- I am looking for open jobs in the pincode [459932](pincode)
- Are there any [tech](role) roles available in the 540089 area?
- I'm a [sales](role) executive with 12 years experience. I was wondering if you had any openings that would suit my background.
- Could you please show me any open [sales](role) positions in the area [560089](pincode)?
- Does area [524422](pincode) have any openings?
- I am looking for open [technical](role) roles in pincode 343321.
- I am currently residing in pincode [560094](pincode). Are there any roles available here?
- I am looking for [sales](role) openings in the [343322](pincode) region.
- My pincode is [443212](pincode). Are there any openings here for a [tech](role) role?


## intent:check_back
- Hi, my name is [Shashank Kumar](name) and I'd applied for a role at your company. Are there any updates on that?
- Hello this is [Shawn](name) checking in about my job application.
- Hi, are there any updates on my job application?
- I had interviewed for a technical role some time ago. Has the decision been made yet?
- Any updates on [Alexander](name)'s interview last week?
